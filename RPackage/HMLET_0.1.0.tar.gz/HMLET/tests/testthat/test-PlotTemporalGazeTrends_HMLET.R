inRead = read.csv("Output_PermutationTestDataPrep.csv")
input_df = inRead[c("testName","ID","trial","timepoint","condition","AOI")]

test_that("plot gaze trends works", {
  test_plot <- PlotTemporalGazeTrends_HMLET(input_df)
  vdiffr::expect_doppelganger("Temporal Gaze Trends", test_plot)
})

# include more tests that play with different sets of parameters?
