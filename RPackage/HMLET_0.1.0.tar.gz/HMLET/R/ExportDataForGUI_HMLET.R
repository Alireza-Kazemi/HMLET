#' ExportDataForGUI_HMLET
#' Export samples of trial with maximum time point to CSV file for MATLAB GUI.
#'
#' @param data dataframe containing temporal data.
#' @param ID optional string for column name that represents IDs within data frame, defaults to "ID."
#' @param trial string for column name that represents trials within data frame, for example "TrialNum."
#' @param timepoint string for column name that represents time intervals, for example "timeStamp."
#' @param timeMax optional integer for maximum time in temporal order, samples are left out if duration is longer. Defaults to 3000.
#' @param samplingDuration optional integer or character for specified duration of samples, used for time bins in CreateTimeBinData_HMLET.
#' @param timeForward optional boolean to sort timebins, defaults to True for ascending order.
#' @param fixation data for specific AOI in dataframe to be fixated on. #TODO: ASK
#' @param condition string for column name that specifies a condition within the data frame.
#' @param testName optional string for name of data -- used as condition name or test names to compare permutation test
#'                 results between different tests/conditions later, defaults to NULL.
#' @param gazeX integer X-coordinate of gaze point on the screen according to top left corner.
#' @param gazeY integer Y-coordinate of gaze point on the screen according to top left corner.
#' @param gazeXRelative optional integer X-coordinate of gaze point relative to an arbitrary center.
#' @param gazeYRelative optional integer Y-coordinate of gaze point relative to an arbitrary center.
#' @param miscVars optional list of strings containing column names of additional variables to be included in exported file
#' @param fileName optional string for output csv file, defaults to "ETDataforMATLAB.csv."
#'
#' @export
ExportDataForMATLAB_HMLET <- function(data, ID = "ID", trial = "trial", timepoint = "timepoint",
                                     timeMax = 3000, samplingDuration, timeForward = T,
                                     fixation, condition, testName = NULL,
                                     gazeX, gazeY, gazeXRelative = NULL, gazeYRelative = NULL,
                                     miscVars = NULL,
                                     fileName = "ETDataforMATLAB.csv", path = getwd()){

  if(is.null(testName)){
    data$testName = unique("PermutationTest0")
    testName = "testName"
  }
  if(is.null(gazeXRelative) | is.null(gazeYRelative)){
    data$gazeXRelative = unique(NA)
    data$gazeYRelative = unique(NA)
  }
  if(is.character(samplingDuration)){
    data$duration = data[,samplingDuration]
  }else if(is.numeric(samplingDuration)){
    data$duration = unique(samplingDuration)
  }

  data = data[,c(testName, ID, trial, timepoint, condition, "duration",
                 gazeX, gazeY, gazeXRelative, gazeYRelative, fixation, miscVars)]
  names(data) = c("testName", "ID", "trial", "timepoint", "condition", "duration",
                 "gazeX", "gazeY", "gazeXRelative", "gazeYRelative", "fixation", miscVars)


  data = CreateTimeBinData_HMLET(data, groupingColumns = NULL, timeBinWidth =  unique(data$duration),
                                timeMax = timeMax, FixatedOn = "fixation",
                                timepoint = "timepoint", AOIs = NULL ,
                                timeForward = timeForward, aggregateFun = mean)




  write.csv(data, paste(path, fileName, sep = .Platform$file.sep), row.names = F)
  print(paste("Data is saved in",getwd(),.Platform$file.sep,fileName, sep=""))

}
